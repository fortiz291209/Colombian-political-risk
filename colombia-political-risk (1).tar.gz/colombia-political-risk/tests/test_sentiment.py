"""
Unit tests for sentiment scoring and signal generation.
Author: Fernando Ortiz Sierra
"""

import numpy as np
import pandas as pd
import unittest
import sys
sys.path.insert(0, '..')

from src.signal_generator import SignalGenerator
from src.nlp_pipeline import SentimentAggregator


class TestSentimentAggregator(unittest.TestCase):

    def setUp(self):
        dates = pd.date_range('2022-01-01', periods=100, freq='D')
        self.scores = pd.DataFrame({
            'energy_policy': np.random.uniform(-1, 1, 100),
            'fiscal_policy': np.random.uniform(-1, 1, 100),
            'market_confidence': np.random.uniform(-1, 1, 100),
            'political_stability': np.random.uniform(-1, 1, 100),
            'em_contagion': np.random.uniform(-1, 1, 100),
        }, index=dates)
        self.agg = SentimentAggregator()

    def test_composite_bounds(self):
        composite = self.agg.daily_composite(self.scores)
        self.assertTrue(composite.min() >= -1.0)
        self.assertTrue(composite.max() <= 1.0)

    def test_ewm_smoothing(self):
        composite = self.agg.daily_composite(self.scores)
        smoothed = self.agg.ewm_smooth(composite)
        self.assertEqual(len(smoothed), len(composite))
        self.assertTrue(smoothed.std() < composite.std())

    def test_zscore_mean_near_zero(self):
        composite = self.agg.daily_composite(self.scores)
        z = self.agg.z_score(composite, lookback=20)
        z_clean = z.dropna()
        self.assertAlmostEqual(z_clean.mean(), 0, delta=0.5)

    def test_weekly_reduces_length(self):
        composite = self.agg.daily_composite(self.scores)
        weekly = self.agg.weekly_aggregate(composite)
        self.assertTrue(len(weekly) < len(composite))

    def test_full_pipeline_columns(self):
        result = self.agg.full_pipeline(self.scores)
        self.assertIn('sentiment_raw', result.columns)
        self.assertIn('sentiment_smoothed', result.columns)
        self.assertIn('sentiment_zscore', result.columns)


class TestSignalGenerator(unittest.TestCase):

    def setUp(self):
        dates = pd.date_range('2022-01-01', periods=200, freq='D')
        self.sentiment = pd.DataFrame({
            'sentiment_zscore': np.random.normal(0, 1, 200),
            'sentiment_raw': np.random.uniform(-1, 1, 200),
        }, index=dates)
        self.market = pd.DataFrame({
            'usdcop_close': 4000 + np.cumsum(np.random.normal(0, 20, 200)),
            'vix_close': 20 + np.random.normal(0, 3, 200),
        }, index=dates)
        self.gen = SignalGenerator()

    def test_signals_have_correct_columns(self):
        signals = self.gen.generate_signals(self.sentiment, self.market)
        self.assertIn('direction', signals.columns)
        self.assertIn('strength', signals.columns)
        self.assertIn('trigger', signals.columns)

    def test_direction_values(self):
        signals = self.gen.generate_signals(self.sentiment, self.market)
        unique = set(signals['direction'].unique())
        self.assertTrue(unique.issubset({-1, 0, 1}))

    def test_strength_bounds(self):
        signals = self.gen.generate_signals(self.sentiment, self.market)
        active = signals[signals['direction'] != 0]
        if len(active) > 0:
            self.assertTrue(active['strength'].min() >= 0)
            self.assertTrue(active['strength'].max() <= 1)

    def test_vix_filter(self):
        self.market['vix_close'] = 35  # all above filter
        signals = self.gen.generate_signals(self.sentiment, self.market)
        active = signals[(signals['direction'] != 0) & (signals['trigger'] != 'vix_filter')]
        self.assertEqual(len(active), 0)

    def test_summary(self):
        signals = self.gen.generate_signals(self.sentiment, self.market)
        summary = self.gen.signal_summary(signals)
        self.assertIn('total_signals', summary)
        self.assertIn('long_signals', summary)
        self.assertIn('short_signals', summary)


if __name__ == '__main__':
    unittest.main()
