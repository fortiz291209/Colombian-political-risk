"""
NLP Sentiment Pipeline
Extracts political sentiment from Colombian government communications
using LLMs (OpenAI API) with structured scoring across five risk dimensions.

Author: Fernando Ortiz Sierra
Period: 2021-2024
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
import json
import logging
import hashlib
from datetime import datetime

logger = logging.getLogger(__name__)


SENTIMENT_DIMENSIONS = [
    'energy_policy',      # stance on oil exploration, Ecopetrol, mining
    'fiscal_policy',      # tax reform, spending, deficit
    'market_confidence',  # investor-facing language, FDI, trade
    'political_stability', # coalition, protests, institutional friction
    'em_contagion',       # regional political spillovers
]

SYSTEM_PROMPT = """You are an expert analyst of Colombian political communications.
Given a political text (speech, press release, tweet, or policy announcement),
score the following five dimensions on a scale from -1.0 (very negative for markets)
to +1.0 (very positive for markets):

1. energy_policy: Does this text signal support for oil/gas exploration and mining,
   or restriction/moratorium? Pro-extraction = positive, anti-extraction = negative.
2. fiscal_policy: Does this signal fiscal discipline or expansion? Tax increases,
   deficit spending = negative. Fiscal restraint, investor-friendly tax = positive.
3. market_confidence: Does the language reassure or alarm investors? FDI-friendly,
   trade openness = positive. Capital controls, nationalization rhetoric = negative.
4. political_stability: Does this indicate stable governance or crisis? Coalition
   unity, institutional respect = positive. Cabinet reshuffles, protests = negative.
5. em_contagion: Does this reference regional instability that could spill over?
   Regional cooperation = positive. References to Argentine/Venezuelan-style
   policies = negative.

Respond ONLY with a JSON object with these five keys and float values between -1.0 and 1.0.
No explanation, no markdown, no preamble."""


class SentimentExtractor:
    """
    Extracts structured sentiment scores from Spanish-language political texts
    using OpenAI's API with a calibrated prompt and caching layer.
    """

    def __init__(self, model: str = 'gpt-4', cache_dir: str = 'data/sentiment_cache'):
        self.model = model
        self.cache_dir = cache_dir
        self.cache = {}
        self._load_cache()

    def _text_hash(self, text: str) -> str:
        return hashlib.md5(text.encode('utf-8')).hexdigest()

    def _load_cache(self):
        """Load cached sentiment scores to avoid redundant API calls."""
        import os
        if os.path.exists(self.cache_dir):
            for f in os.listdir(self.cache_dir):
                if f.endswith('.json'):
                    with open(os.path.join(self.cache_dir, f)) as fp:
                        data = json.load(fp)
                        self.cache[f.replace('.json', '')] = data

    def _save_to_cache(self, text_hash: str, scores: Dict):
        import os
        os.makedirs(self.cache_dir, exist_ok=True)
        with open(os.path.join(self.cache_dir, f"{text_hash}.json"), 'w') as fp:
            json.dump(scores, fp)

    def extract_sentiment(self, text: str, date: str, source: str = '') -> Dict:
        """
        Extract sentiment scores from a single political text.
        Returns dict with five dimension scores and metadata.
        """
        text_hash = self._text_hash(text)

        if text_hash in self.cache:
            logger.debug(f"Cache hit for {date}")
            return self.cache[text_hash]

        try:
            import openai
            response = openai.ChatCompletion.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": f"Date: {date}\nSource: {source}\n\nText:\n{text}"}
                ],
                temperature=0.1,
                max_tokens=200,
            )

            raw = response.choices[0].message.content.strip()
            raw = raw.replace('```json', '').replace('```', '').strip()
            scores = json.loads(raw)

            for dim in SENTIMENT_DIMENSIONS:
                if dim not in scores:
                    scores[dim] = 0.0
                scores[dim] = np.clip(float(scores[dim]), -1.0, 1.0)

            scores['date'] = date
            scores['source'] = source
            scores['text_hash'] = text_hash

            self.cache[text_hash] = scores
            self._save_to_cache(text_hash, scores)

            return scores

        except Exception as e:
            logger.error(f"Sentiment extraction failed for {date}: {e}")
            return {dim: 0.0 for dim in SENTIMENT_DIMENSIONS}

    def batch_extract(self, texts_df: pd.DataFrame) -> pd.DataFrame:
        """
        Process a DataFrame of political texts.
        Expected columns: date, text, source
        """
        results = []
        for _, row in texts_df.iterrows():
            scores = self.extract_sentiment(
                text=row['text'],
                date=str(row.get('date', '')),
                source=row.get('source', '')
            )
            results.append(scores)

        scores_df = pd.DataFrame(results)
        if 'date' in scores_df.columns:
            scores_df['date'] = pd.to_datetime(scores_df['date'])
            scores_df.set_index('date', inplace=True)
        return scores_df


class SentimentAggregator:
    """
    Aggregates raw sentiment scores into daily and weekly signals.
    Applies exponential decay weighting, z-score normalization,
    and dimension-weighted composite scoring.
    """

    DEFAULT_WEIGHTS = {
        'energy_policy': 0.35,
        'fiscal_policy': 0.25,
        'market_confidence': 0.20,
        'political_stability': 0.15,
        'em_contagion': 0.05,
    }

    def __init__(self, weights: Optional[Dict] = None, halflife_days: int = 5):
        self.weights = weights or self.DEFAULT_WEIGHTS
        self.halflife = halflife_days

    def daily_composite(self, scores_df: pd.DataFrame) -> pd.Series:
        """Compute weighted daily composite sentiment score."""
        composite = pd.Series(0.0, index=scores_df.index)
        for dim, weight in self.weights.items():
            if dim in scores_df.columns:
                composite += weight * scores_df[dim]
        return composite.rename('sentiment_composite')

    def ewm_smooth(self, series: pd.Series) -> pd.Series:
        """Apply exponential decay smoothing."""
        return series.ewm(halflife=self.halflife).mean().rename(f"{series.name}_ewm")

    def z_score(self, series: pd.Series, lookback: int = 60) -> pd.Series:
        """Rolling z-score normalization."""
        mu = series.rolling(lookback).mean()
        sigma = series.rolling(lookback).std()
        z = (series - mu) / sigma.replace(0, np.nan)
        return z.rename(f"{series.name}_zscore")

    def weekly_aggregate(self, daily_scores: pd.Series) -> pd.Series:
        """Resample to weekly frequency using last observation."""
        return daily_scores.resample('W-FRI').last().rename(f"{daily_scores.name}_weekly")

    def full_pipeline(self, scores_df: pd.DataFrame) -> pd.DataFrame:
        """Run full aggregation pipeline."""
        composite = self.daily_composite(scores_df)
        smoothed = self.ewm_smooth(composite)
        z = self.z_score(smoothed)
        weekly = self.weekly_aggregate(composite)

        result = pd.DataFrame({
            'sentiment_raw': composite,
            'sentiment_smoothed': smoothed,
            'sentiment_zscore': z,
        })

        for dim in SENTIMENT_DIMENSIONS:
            if dim in scores_df.columns:
                result[f"{dim}_zscore"] = self.z_score(scores_df[dim])

        return result
