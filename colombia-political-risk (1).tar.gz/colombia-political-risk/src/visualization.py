"""
Visualization Module
Publication-quality charts for sentiment analysis, event studies,
backtesting results, and regime classification.

Author: Fernando Ortiz Sierra
Period: 2021-2024
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)

plt.rcParams.update({
    'figure.figsize': (14, 8),
    'font.size': 11,
    'axes.titlesize': 13,
    'axes.labelsize': 11,
    'legend.fontsize': 10,
    'figure.dpi': 150,
    'savefig.dpi': 300,
    'savefig.bbox_inches': 'tight',
})


def plot_sentiment_timeline(sentiment: pd.DataFrame, events: pd.DataFrame,
                            save_path: Optional[str] = None):
    """Plot sentiment scores over time with political event markers."""
    fig, axes = plt.subplots(3, 1, figsize=(16, 12), sharex=True)

    # Raw composite sentiment
    ax = axes[0]
    ax.plot(sentiment.index, sentiment['sentiment_raw'], color='steelblue', alpha=0.4, lw=0.8)
    ax.plot(sentiment.index, sentiment['sentiment_smoothed'], color='darkblue', lw=1.5, label='EWM Smoothed')
    ax.axhline(0, color='gray', ls='--', lw=0.5)
    ax.set_ylabel('Composite Sentiment')
    ax.set_title('Political Sentiment: Colombia (2021-2024)')
    ax.legend()

    # Z-score
    ax = axes[1]
    ax.fill_between(sentiment.index, sentiment['sentiment_zscore'], 0,
                    where=sentiment['sentiment_zscore'] > 0, color='green', alpha=0.3)
    ax.fill_between(sentiment.index, sentiment['sentiment_zscore'], 0,
                    where=sentiment['sentiment_zscore'] < 0, color='red', alpha=0.3)
    ax.axhline(2, color='green', ls=':', lw=0.8)
    ax.axhline(-2, color='red', ls=':', lw=0.8)
    ax.set_ylabel('Sentiment Z-Score')

    # Event markers on all panels
    for ax in axes[:2]:
        for date, row in events.iterrows():
            color = {'critical': 'red', 'high': 'orange', 'medium': 'gray'}.get(
                row.get('severity', 'medium'), 'gray')
            ax.axvline(date, color=color, ls='--', alpha=0.5, lw=0.8)

    # Dimension breakdown
    ax = axes[2]
    dims = ['energy_policy_zscore', 'fiscal_policy_zscore', 'market_confidence_zscore',
            'political_stability_zscore']
    colors = ['#e74c3c', '#3498db', '#2ecc71', '#9b59b6']
    for dim, color in zip(dims, colors):
        if dim in sentiment.columns:
            ax.plot(sentiment.index, sentiment[dim], color=color, alpha=0.7, lw=1,
                   label=dim.replace('_zscore', ''))
    ax.set_ylabel('Dimension Z-Scores')
    ax.legend(loc='lower left', ncol=2)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
    return fig


def plot_event_study(event_results: pd.DataFrame, save_path: Optional[str] = None):
    """Plot cumulative abnormal returns across events."""
    fig, ax = plt.subplots(figsize=(12, 6))

    events = event_results.sort_values('event_date')
    x = range(len(events))
    colors = ['red' if t < -1.96 else 'green' if t > 1.96 else 'gray'
              for t in events['t_stat_10d']]

    ax.bar(x, events['car_10d'] * 100, color=colors, alpha=0.7, edgecolor='black', lw=0.5)
    ax.set_xticks(x)
    ax.set_xticklabels(events['event_name'], rotation=45, ha='right', fontsize=9)
    ax.set_ylabel('CAR [0, +10] (%)')
    ax.set_title('Cumulative Abnormal Returns: Colombian Political Events')
    ax.axhline(0, color='black', lw=0.8)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
    return fig


def plot_backtest_results(results: pd.DataFrame, benchmark: pd.Series = None,
                          save_path: Optional[str] = None):
    """Plot backtest portfolio value, drawdowns, and position exposure."""
    fig, axes = plt.subplots(3, 1, figsize=(16, 12), sharex=True,
                             gridspec_kw={'height_ratios': [3, 1, 1]})

    # Portfolio value
    ax = axes[0]
    ax.plot(results.index, results['portfolio_value'], color='darkblue', lw=1.5, label='Strategy')
    if benchmark is not None:
        bench_norm = benchmark / benchmark.iloc[0] * results['portfolio_value'].iloc[0]
        ax.plot(bench_norm.index, bench_norm, color='gray', lw=1, alpha=0.7, label='Benchmark')
    ax.set_ylabel('Portfolio Value ($)')
    ax.set_title('Strategy Performance: Colombian Political Risk')
    ax.legend()
    ax.grid(True, alpha=0.3)

    # Drawdown
    ax = axes[1]
    ax.fill_between(results.index, -results['drawdown'] * 100, 0, color='red', alpha=0.4)
    ax.set_ylabel('Drawdown (%)')
    ax.set_ylim(ax.get_ylim()[0], 0.5)

    # Position
    ax = axes[2]
    ax.fill_between(results.index, results['position'], 0,
                    where=results['position'] > 0, color='green', alpha=0.4, label='Long')
    ax.fill_between(results.index, results['position'], 0,
                    where=results['position'] < 0, color='red', alpha=0.4, label='Short')
    ax.set_ylabel('Position')
    ax.legend(loc='upper left')

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
    return fig


def plot_did_comparison(treatment_cum: pd.Series, control_cum: pd.Series,
                        event_date: pd.Timestamp, event_name: str = '',
                        save_path: Optional[str] = None):
    """Plot DiD parallel trends and treatment effect."""
    fig, ax = plt.subplots(figsize=(12, 6))

    ax.plot(treatment_cum.index, treatment_cum * 100, color='darkblue', lw=1.5,
            label='Colombia (Treatment)')
    ax.plot(control_cum.index, control_cum * 100, color='gray', lw=1.5,
            label='EM Peers (Control)')
    ax.axvline(event_date, color='red', ls='--', lw=1.5, label=f'Event: {event_name}')
    ax.axhline(0, color='black', lw=0.5)
    ax.set_xlabel('Date')
    ax.set_ylabel('Cumulative Returns (%)')
    ax.set_title(f'Difference-in-Differences: {event_name}')
    ax.legend()
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
    return fig
