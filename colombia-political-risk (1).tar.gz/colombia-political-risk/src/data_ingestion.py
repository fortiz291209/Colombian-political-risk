"""
Data Ingestion Module
Collects market data, macro indicators, and political text data
for Colombian political risk analysis.

Author: Fernando Ortiz Sierra
Period: 2021-2024
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class MarketDataFetcher:
    """
    Fetches and aligns daily market data for Colombian political risk research.
    Sources: Yahoo Finance (primary), FRED (macro), Banco de la Republica (policy rate).
    """

    TICKERS = {
        'brent': 'BZ=F',
        'wti': 'CL=F',
        'gold': 'GC=F',
        'usdcop': 'COP=X',
        'usdbrl': 'BRL=X',
        'usdmxn': 'MXN=X',
        'colcap': '^COLCAP',
        'ecopetrol': 'EC',
        'vix': '^VIX',
        'dxy': 'DX-Y.NYB',
        'spy': 'SPY',
        'eem': 'EEM',  # EM ETF for control group
    }

    FRED_SERIES = {
        'us10y': 'DGS10',
        'colombian_policy_rate': None,  # manual input from BanRep
        'us_cpi': 'CPIAUCSL',
        'em_spread': 'BAMLEMCBPIOAS',  # ICE BofA EM Corporate spread
    }

    def __init__(self, start_date: str = '2021-01-01', end_date: str = '2024-07-01'):
        self.start = pd.Timestamp(start_date)
        self.end = pd.Timestamp(end_date)
        self.data = {}

    def fetch_yahoo(self, ticker: str, name: str) -> pd.DataFrame:
        """Fetch OHLCV data from Yahoo Finance."""
        try:
            import yfinance as yf
            df = yf.download(ticker, start=self.start, end=self.end, progress=False)
            if df.empty:
                logger.warning(f"No data returned for {name} ({ticker})")
                return pd.DataFrame()
            df.columns = [f"{name}_{c.lower()}" for c in df.columns]
            logger.info(f"Fetched {len(df)} rows for {name}")
            return df
        except Exception as e:
            logger.error(f"Failed to fetch {name}: {e}")
            return pd.DataFrame()

    def fetch_fred(self, series_id: str, name: str) -> pd.Series:
        """Fetch macro series from FRED."""
        try:
            import pandas_datareader.data as web
            s = web.DataReader(series_id, 'fred', self.start, self.end)
            logger.info(f"Fetched {len(s)} rows for {name} from FRED")
            return s.iloc[:, 0].rename(name)
        except Exception as e:
            logger.error(f"Failed to fetch {name} from FRED: {e}")
            return pd.Series(dtype=float, name=name)

    def fetch_all_market_data(self) -> pd.DataFrame:
        """Fetch and merge all market data into aligned daily DataFrame."""
        frames = []
        for name, ticker in self.TICKERS.items():
            df = self.fetch_yahoo(ticker, name)
            if not df.empty:
                frames.append(df)

        if not frames:
            raise ValueError("No market data fetched")

        merged = pd.concat(frames, axis=1)
        merged = merged.ffill().dropna(how='all')
        self.data['market'] = merged
        logger.info(f"Merged market data: {merged.shape}")
        return merged

    def compute_returns(self, df: pd.DataFrame, price_cols: List[str]) -> pd.DataFrame:
        """Compute log returns for specified price columns."""
        returns = pd.DataFrame(index=df.index)
        for col in price_cols:
            if col in df.columns:
                returns[f"{col}_ret"] = np.log(df[col] / df[col].shift(1))
                returns[f"{col}_ret_5d"] = np.log(df[col] / df[col].shift(5))
                returns[f"{col}_ret_20d"] = np.log(df[col] / df[col].shift(20))
        return returns.dropna()

    def compute_volatility(self, returns: pd.Series, windows: List[int] = [5, 20, 60]) -> pd.DataFrame:
        """Compute rolling realized volatility at multiple windows."""
        vol = pd.DataFrame(index=returns.index)
        for w in windows:
            vol[f"rvol_{w}d"] = returns.rolling(w).std() * np.sqrt(252)
        return vol


class PoliticalDataCollector:
    """
    Collects and structures political text data from Colombian government sources.
    Sources: Presidential press office, ministerial communications, congressional records.
    """

    EVENT_CATALOG = {
        '2022-05-29': {'event': 'Petro wins first round', 'type': 'election', 'severity': 'high'},
        '2022-06-19': {'event': 'Petro wins presidency', 'type': 'election', 'severity': 'critical'},
        '2022-08-15': {'event': 'Drilling moratorium rhetoric', 'type': 'energy_policy', 'severity': 'high'},
        '2022-11-04': {'event': 'Tax reform passed', 'type': 'fiscal', 'severity': 'medium'},
        '2023-03-10': {'event': 'Ecopetrol dividend cut rumors', 'type': 'energy_policy', 'severity': 'high'},
        '2023-06-20': {'event': 'Mining regulation proposal', 'type': 'regulation', 'severity': 'medium'},
        '2023-08-15': {'event': 'Cabinet reshuffle', 'type': 'stability', 'severity': 'medium'},
        '2023-12-05': {'event': 'Political crisis deepens', 'type': 'stability', 'severity': 'high'},
        '2024-02-20': {'event': 'Health reform collapse', 'type': 'legislative', 'severity': 'medium'},
        '2024-03-15': {'event': 'Pension reform debate', 'type': 'fiscal', 'severity': 'medium'},
    }

    def __init__(self):
        self.texts = []
        self.events = pd.DataFrame.from_dict(self.EVENT_CATALOG, orient='index')
        self.events.index = pd.to_datetime(self.events.index)
        self.events.index.name = 'date'

    def load_political_texts(self, directory: str) -> pd.DataFrame:
        """Load processed political text data from directory."""
        import os
        import json

        records = []
        if os.path.exists(directory):
            for f in sorted(os.listdir(directory)):
                if f.endswith('.json'):
                    with open(os.path.join(directory, f)) as fp:
                        records.append(json.load(fp))

        if records:
            df = pd.DataFrame(records)
            df['date'] = pd.to_datetime(df['date'])
            df.set_index('date', inplace=True)
            return df

        logger.warning(f"No political text data found in {directory}")
        return pd.DataFrame()

    def get_event_windows(self, pre_days: int = 5, post_days: int = 20) -> Dict:
        """Generate event windows for event study analysis."""
        windows = {}
        for date, row in self.events.iterrows():
            windows[date] = {
                'event': row['event'],
                'type': row['type'],
                'severity': row['severity'],
                'pre_start': date - pd.Timedelta(days=pre_days),
                'pre_end': date - pd.Timedelta(days=1),
                'post_start': date,
                'post_end': date + pd.Timedelta(days=post_days),
                'estimation_start': date - pd.Timedelta(days=120),
                'estimation_end': date - pd.Timedelta(days=20),
            }
        return windows
