"""
Event Study and Difference-in-Differences Framework
Formal econometric analysis of Colombian political events on asset prices.

Author: Fernando Ortiz Sierra
Period: 2021-2024
"""

import numpy as np
import pandas as pd
from scipy import stats
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class EventResult:
    event_date: pd.Timestamp
    event_name: str
    car_5d: float
    car_10d: float
    car_20d: float
    t_stat_5d: float
    t_stat_10d: float
    t_stat_20d: float
    alpha: float
    beta: float
    r_squared: float


class EventStudy:
    """
    Classical event study methodology for political event analysis.
    Computes abnormal returns against a market model estimated
    on [-120, -20] pre-event window.
    """

    def __init__(self, estimation_window: Tuple[int, int] = (-120, -20),
                 event_windows: List[int] = [5, 10, 20]):
        self.est_start, self.est_end = estimation_window
        self.event_windows = event_windows

    def _estimate_market_model(self, treatment_ret: pd.Series,
                                market_ret: pd.Series,
                                event_date: pd.Timestamp) -> Tuple[float, float, float]:
        """OLS market model: r_i = alpha + beta * r_m + epsilon."""
        dates = treatment_ret.index
        est_mask = (dates >= event_date + pd.Timedelta(days=self.est_start)) & \
                   (dates <= event_date + pd.Timedelta(days=self.est_end))

        y = treatment_ret[est_mask].dropna()
        x = market_ret.reindex(y.index).dropna()
        y = y.reindex(x.index)

        if len(y) < 30:
            logger.warning(f"Insufficient estimation data for {event_date}")
            return 0, 1, 0

        X = np.column_stack([np.ones(len(x)), x.values])
        beta_hat = np.linalg.lstsq(X, y.values, rcond=None)[0]
        y_hat = X @ beta_hat
        residuals = y.values - y_hat
        ss_res = np.sum(residuals**2)
        ss_tot = np.sum((y.values - y.values.mean())**2)
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0

        return beta_hat[0], beta_hat[1], r2

    def _compute_abnormal_returns(self, treatment_ret: pd.Series,
                                   market_ret: pd.Series,
                                   alpha: float, beta: float,
                                   event_date: pd.Timestamp) -> pd.Series:
        """Compute abnormal returns in post-event window."""
        post_mask = treatment_ret.index >= event_date
        r_actual = treatment_ret[post_mask].iloc[:max(self.event_windows)]
        r_market = market_ret.reindex(r_actual.index)
        r_expected = alpha + beta * r_market
        ar = r_actual - r_expected
        return ar

    def run_event_study(self, treatment_ret: pd.Series,
                        market_ret: pd.Series,
                        event_date: pd.Timestamp,
                        event_name: str = '') -> EventResult:
        """Run single event study and return results."""
        alpha, beta, r2 = self._estimate_market_model(treatment_ret, market_ret, event_date)
        ar = self._compute_abnormal_returns(treatment_ret, market_ret, alpha, beta, event_date)

        # Estimation window residual std for t-statistics
        est_mask = (treatment_ret.index >= event_date + pd.Timedelta(days=self.est_start)) & \
                   (treatment_ret.index <= event_date + pd.Timedelta(days=self.est_end))
        est_returns = treatment_ret[est_mask]
        est_market = market_ret.reindex(est_returns.index)
        est_expected = alpha + beta * est_market
        est_residuals = est_returns - est_expected
        sigma_ar = est_residuals.std()

        cars = {}
        tstats = {}
        for w in self.event_windows:
            car = ar.iloc[:w].sum() if len(ar) >= w else np.nan
            cars[w] = car
            tstats[w] = car / (sigma_ar * np.sqrt(w)) if sigma_ar > 0 else 0

        return EventResult(
            event_date=event_date, event_name=event_name,
            car_5d=cars.get(5, np.nan), car_10d=cars.get(10, np.nan), car_20d=cars.get(20, np.nan),
            t_stat_5d=tstats.get(5, 0), t_stat_10d=tstats.get(10, 0), t_stat_20d=tstats.get(20, 0),
            alpha=alpha, beta=beta, r_squared=r2,
        )

    def run_all_events(self, treatment_ret: pd.Series, market_ret: pd.Series,
                       events: Dict) -> pd.DataFrame:
        """Run event studies for all events in catalog."""
        results = []
        for date, info in events.items():
            if isinstance(date, str):
                date = pd.Timestamp(date)
            result = self.run_event_study(treatment_ret, market_ret, date, info.get('event', ''))
            results.append(result)
        return pd.DataFrame([r.__dict__ for r in results])


class DifferenceInDifferences:
    """
    Difference-in-differences estimation comparing Colombian assets (treatment)
    to comparable EM assets (control) around political events.
    """

    def __init__(self, pre_window: int = 20, post_window: int = 20):
        self.pre_window = pre_window
        self.post_window = post_window

    def estimate(self, treatment_ret: pd.Series, control_ret: pd.Series,
                 event_date: pd.Timestamp) -> Dict:
        """
        2x2 DiD estimation.
        Treatment = Colombian asset, Control = EM peer.
        Pre = [-pre_window, -1], Post = [0, +post_window].
        """
        pre_mask_t = (treatment_ret.index >= event_date - pd.Timedelta(days=self.pre_window)) & \
                     (treatment_ret.index < event_date)
        post_mask_t = (treatment_ret.index >= event_date) & \
                      (treatment_ret.index <= event_date + pd.Timedelta(days=self.post_window))

        pre_treat = treatment_ret[pre_mask_t].mean()
        post_treat = treatment_ret[post_mask_t].mean()
        pre_control = control_ret.reindex(treatment_ret[pre_mask_t].index).mean()
        post_control = control_ret.reindex(treatment_ret[post_mask_t].index).mean()

        did = (post_treat - pre_treat) - (post_control - pre_control)

        # Standard error via pooled variance
        n_pre = pre_mask_t.sum()
        n_post = post_mask_t.sum()
        var_treat = np.concatenate([treatment_ret[pre_mask_t].values, treatment_ret[post_mask_t].values])
        var_control = np.concatenate([
            control_ret.reindex(treatment_ret[pre_mask_t].index).values,
            control_ret.reindex(treatment_ret[post_mask_t].index).values
        ])
        pooled_var = (np.nanvar(var_treat) + np.nanvar(var_control)) / 2
        se = np.sqrt(4 * pooled_var / (n_pre + n_post)) if (n_pre + n_post) > 0 else np.nan
        t_stat = did / se if se > 0 else 0
        p_value = 2 * (1 - stats.t.cdf(abs(t_stat), df=n_pre + n_post - 4))

        return {
            'did_estimate': did,
            'se': se,
            't_stat': t_stat,
            'p_value': p_value,
            'pre_treat': pre_treat,
            'post_treat': post_treat,
            'pre_control': pre_control,
            'post_control': post_control,
            'n_pre': n_pre,
            'n_post': n_post,
        }

    def parallel_trends_test(self, treatment_ret: pd.Series, control_ret: pd.Series,
                             event_date: pd.Timestamp, test_window: int = 60) -> Dict:
        """Test parallel trends assumption in pre-event period."""
        mask = (treatment_ret.index >= event_date - pd.Timedelta(days=test_window)) & \
               (treatment_ret.index < event_date)

        treat_pre = treatment_ret[mask].cumsum()
        ctrl_pre = control_ret.reindex(treat_pre.index).cumsum()
        diff = treat_pre - ctrl_pre

        if len(diff) < 10:
            return {'parallel_trends': False, 'reason': 'insufficient data'}

        # Regress diff on time trend; insignificant slope = parallel trends
        t = np.arange(len(diff))
        X = np.column_stack([np.ones(len(t)), t])
        beta = np.linalg.lstsq(X, diff.values, rcond=None)[0]
        residuals = diff.values - X @ beta
        se_beta = np.sqrt(np.sum(residuals**2) / (len(t) - 2) / np.sum((t - t.mean())**2))
        t_stat = beta[1] / se_beta if se_beta > 0 else 0
        p_value = 2 * (1 - stats.t.cdf(abs(t_stat), df=len(t) - 2))

        return {
            'slope': beta[1],
            'slope_se': se_beta,
            't_stat': t_stat,
            'p_value': p_value,
            'parallel_trends': p_value > 0.05,
        }
