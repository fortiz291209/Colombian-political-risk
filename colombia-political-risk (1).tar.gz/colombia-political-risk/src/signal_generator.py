"""
Signal Generator
Constructs trading signals from NLP sentiment scores and market data.
Implements contrarian positioning logic, regime filters, and signal validation.

Author: Fernando Ortiz Sierra
Period: 2021-2024
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class Signal:
    date: pd.Timestamp
    direction: int       # +1 long, -1 short, 0 flat
    asset: str
    strength: float      # [0, 1] signal conviction
    trigger: str         # which rule fired
    sentiment_z: float
    market_z: float


class SignalGenerator:
    """
    Generates contrarian trading signals when NLP-derived political sentiment
    diverges from market-implied risk pricing.

    Core logic: when the NLP pipeline says political risk is high but markets
    have already overreacted (CDS wide, FX depreciated, oil implied vol elevated),
    go contrarian. When NLP says risk is low but markets haven't adjusted, position
    for the correction.
    """

    def __init__(self, config: Optional[Dict] = None):
        cfg = config or {}
        self.sentiment_buy_threshold = cfg.get('sentiment_buy_threshold', -0.5)
        self.sentiment_sell_threshold = cfg.get('sentiment_sell_threshold', 0.3)
        self.cds_zscore_threshold = cfg.get('cds_zscore_threshold', 2.0)
        self.vix_filter = cfg.get('vix_filter', 30)
        self.min_holding_days = cfg.get('min_holding_days', 5)
        self.max_holding_days = cfg.get('max_holding_days', 20)
        self.lookback = cfg.get('lookback', 60)

    def compute_market_zscore(self, series: pd.Series, window: int = None) -> pd.Series:
        """Rolling z-score for market series (CDS, implied vol, FX)."""
        w = window or self.lookback
        mu = series.rolling(w).mean()
        sigma = series.rolling(w).std()
        return ((series - mu) / sigma.replace(0, np.nan)).rename(f"{series.name}_zscore")

    def generate_signals(self, sentiment: pd.DataFrame, market: pd.DataFrame) -> pd.DataFrame:
        """
        Generate trading signals from sentiment and market data.

        Parameters
        ----------
        sentiment : DataFrame with columns sentiment_zscore, sentiment_raw
        market : DataFrame with columns for FX, oil, CDS, VIX

        Returns
        -------
        DataFrame with signal columns: direction, strength, trigger
        """
        signals = pd.DataFrame(index=sentiment.index)
        signals['direction'] = 0
        signals['strength'] = 0.0
        signals['trigger'] = ''
        signals['sentiment_z'] = sentiment.get('sentiment_zscore', 0)

        # Align market data
        aligned = market.reindex(sentiment.index).ffill()

        # Compute market z-scores
        if 'usdcop_close' in aligned.columns:
            fx_z = self.compute_market_zscore(aligned['usdcop_close'])
        else:
            fx_z = pd.Series(0, index=signals.index)

        if 'vix_close' in aligned.columns:
            vix = aligned['vix_close']
        else:
            vix = pd.Series(15, index=signals.index)

        signals['market_z'] = fx_z

        for i, date in enumerate(signals.index):
            sent_z = signals.loc[date, 'sentiment_z']
            mkt_z = fx_z.get(date, 0)
            current_vix = vix.get(date, 15)

            if np.isnan(sent_z) or np.isnan(mkt_z):
                continue

            # Global risk-off filter: skip during systemic events
            if current_vix > self.vix_filter:
                signals.loc[date, 'trigger'] = 'vix_filter'
                continue

            # Contrarian long: sentiment very negative, market already overreacted
            if sent_z < self.sentiment_buy_threshold and mkt_z > self.cds_zscore_threshold:
                signals.loc[date, 'direction'] = 1
                signals.loc[date, 'strength'] = min(abs(sent_z) * 0.5, 1.0)
                signals.loc[date, 'trigger'] = 'contrarian_long'

            # Contrarian short: sentiment positive, market hasn't adjusted
            elif sent_z > self.sentiment_sell_threshold and mkt_z < -1.0:
                signals.loc[date, 'direction'] = -1
                signals.loc[date, 'strength'] = min(abs(sent_z) * 0.4, 1.0)
                signals.loc[date, 'trigger'] = 'contrarian_short'

        # Apply minimum holding period
        signals = self._apply_holding_period(signals)

        n_long = (signals['direction'] == 1).sum()
        n_short = (signals['direction'] == -1).sum()
        logger.info(f"Generated {n_long} long signals, {n_short} short signals")

        return signals

    def _apply_holding_period(self, signals: pd.DataFrame) -> pd.DataFrame:
        """Enforce minimum holding period between signal changes."""
        last_signal_date = None
        for date in signals.index:
            if signals.loc[date, 'direction'] != 0:
                if last_signal_date is not None:
                    days_since = (date - last_signal_date).days
                    if days_since < self.min_holding_days:
                        signals.loc[date, 'direction'] = 0
                        signals.loc[date, 'trigger'] = 'holding_filter'
                        continue
                last_signal_date = date
        return signals

    def signal_summary(self, signals: pd.DataFrame) -> Dict:
        """Compute summary statistics for generated signals."""
        active = signals[signals['direction'] != 0]
        return {
            'total_signals': len(active),
            'long_signals': (active['direction'] == 1).sum(),
            'short_signals': (active['direction'] == -1).sum(),
            'avg_strength': active['strength'].mean(),
            'triggers': active['trigger'].value_counts().to_dict(),
            'first_signal': active.index.min(),
            'last_signal': active.index.max(),
        }
