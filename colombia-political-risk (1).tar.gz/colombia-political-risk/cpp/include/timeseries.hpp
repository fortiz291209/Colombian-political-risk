/**
 * @file timeseries.hpp
 * @brief Time series analytics for political risk signal processing
 * @author Fernando Ortiz Sierra
 * @date 2021-2024
 *
 * Fast computation of rolling statistics, event study abnormal returns,
 * and signal metrics used in the Colombian political risk framework.
 */

#pragma once

#include <vector>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <stdexcept>
#include <limits>

namespace cpr {

// ============================================================
// Rolling window computations
// ============================================================

/**
 * Compute rolling z-score for an entire time series.
 * Used for sentiment normalization and market indicator scoring.
 */
inline std::vector<double> rolling_zscore(
    const std::vector<double>& data,
    int window
) {
    int n = static_cast<int>(data.size());
    std::vector<double> result(n, std::numeric_limits<double>::quiet_NaN());

    if (n < window || window < 2) return result;

    double sum = 0.0, sum_sq = 0.0;
    for (int i = 0; i < window; ++i) {
        sum += data[i];
        sum_sq += data[i] * data[i];
    }

    for (int i = window; i <= n; ++i) {
        double mean = sum / window;
        double var = (sum_sq / window) - mean * mean;
        double std = std::sqrt(std::max(0.0, var));
        result[i - 1] = std > 1e-10 ? (data[i - 1] - mean) / std : 0.0;

        if (i < n) {
            sum += data[i] - data[i - window];
            sum_sq += data[i] * data[i] - data[i - window] * data[i - window];
        }
    }
    return result;
}

/**
 * Exponentially weighted moving average.
 * halflife: number of periods for weight to decay by half.
 */
inline std::vector<double> ewma(
    const std::vector<double>& data,
    double halflife
) {
    int n = static_cast<int>(data.size());
    std::vector<double> result(n, 0.0);
    if (n == 0) return result;

    double alpha = 1.0 - std::exp(-std::log(2.0) / halflife);
    result[0] = data[0];
    for (int i = 1; i < n; ++i) {
        result[i] = alpha * data[i] + (1.0 - alpha) * result[i - 1];
    }
    return result;
}

/**
 * Compute log returns from price series.
 */
inline std::vector<double> log_returns(const std::vector<double>& prices) {
    int n = static_cast<int>(prices.size());
    std::vector<double> ret(n, 0.0);
    for (int i = 1; i < n; ++i) {
        if (prices[i - 1] > 0) {
            ret[i] = std::log(prices[i] / prices[i - 1]);
        }
    }
    return ret;
}

/**
 * Rolling realized volatility (annualized).
 */
inline std::vector<double> rolling_volatility(
    const std::vector<double>& returns,
    int window,
    double annualization = 252.0
) {
    int n = static_cast<int>(returns.size());
    std::vector<double> vol(n, 0.0);

    for (int i = window; i <= n; ++i) {
        double sum = 0.0, sum_sq = 0.0;
        for (int j = i - window; j < i; ++j) {
            sum += returns[j];
            sum_sq += returns[j] * returns[j];
        }
        double mean = sum / window;
        double var = (sum_sq / window) - mean * mean;
        vol[i - 1] = std::sqrt(std::max(0.0, var) * annualization);
    }
    return vol;
}

// ============================================================
// Event study computations
// ============================================================

struct OLSResult {
    double alpha;
    double beta;
    double r_squared;
    double residual_std;
};

/**
 * OLS market model estimation: r_i = alpha + beta * r_m + eps
 */
inline OLSResult ols_market_model(
    const std::vector<double>& treatment,
    const std::vector<double>& market,
    int start, int end
) {
    if (end <= start || end > static_cast<int>(treatment.size())) {
        return {0, 1, 0, 0};
    }

    int n = end - start;
    double sx = 0, sy = 0, sxy = 0, sxx = 0;

    for (int i = start; i < end; ++i) {
        sx += market[i];
        sy += treatment[i];
        sxy += market[i] * treatment[i];
        sxx += market[i] * market[i];
    }

    double mx = sx / n;
    double my = sy / n;
    double beta = (sxy - n * mx * my) / (sxx - n * mx * mx + 1e-15);
    double alpha = my - beta * mx;

    double ss_res = 0, ss_tot = 0;
    for (int i = start; i < end; ++i) {
        double predicted = alpha + beta * market[i];
        double residual = treatment[i] - predicted;
        ss_res += residual * residual;
        ss_tot += (treatment[i] - my) * (treatment[i] - my);
    }

    double r2 = ss_tot > 0 ? 1.0 - ss_res / ss_tot : 0.0;
    double res_std = std::sqrt(ss_res / std::max(1, n - 2));

    return {alpha, beta, r2, res_std};
}

/**
 * Compute cumulative abnormal returns for an event window.
 */
inline std::vector<double> cumulative_abnormal_returns(
    const std::vector<double>& treatment,
    const std::vector<double>& market,
    double alpha, double beta,
    int event_idx, int post_window
) {
    int n = static_cast<int>(treatment.size());
    std::vector<double> car;
    car.reserve(post_window);

    double cumulative = 0.0;
    for (int i = event_idx; i < std::min(event_idx + post_window, n); ++i) {
        double expected = alpha + beta * market[i];
        double abnormal = treatment[i] - expected;
        cumulative += abnormal;
        car.push_back(cumulative);
    }
    return car;
}

/**
 * Compute t-statistic for CAR.
 */
inline double car_tstat(double car_value, double residual_std, int window) {
    if (residual_std <= 0 || window <= 0) return 0.0;
    return car_value / (residual_std * std::sqrt(static_cast<double>(window)));
}

// ============================================================
// Risk metrics
// ============================================================

struct RiskMetrics {
    double var_95;
    double var_99;
    double cvar_95;
    double cvar_99;
    double max_drawdown;
    double sharpe;
    double sortino;
};

/**
 * Compute VaR and CVaR from a return series via historical simulation.
 */
inline RiskMetrics compute_risk_metrics(
    const std::vector<double>& returns,
    double annualization = 252.0
) {
    RiskMetrics rm{};
    if (returns.size() < 10) return rm;

    std::vector<double> sorted_ret(returns);
    std::sort(sorted_ret.begin(), sorted_ret.end());

    int n = static_cast<int>(sorted_ret.size());
    int idx_5 = static_cast<int>(0.05 * n);
    int idx_1 = static_cast<int>(0.01 * n);

    rm.var_95 = -sorted_ret[idx_5];
    rm.var_99 = -sorted_ret[idx_1];

    // CVaR = mean of returns below VaR
    double sum_95 = 0.0, sum_99 = 0.0;
    for (int i = 0; i <= idx_5; ++i) sum_95 += sorted_ret[i];
    for (int i = 0; i <= idx_1; ++i) sum_99 += sorted_ret[i];
    rm.cvar_95 = idx_5 > 0 ? -sum_95 / (idx_5 + 1) : 0.0;
    rm.cvar_99 = idx_1 > 0 ? -sum_99 / (idx_1 + 1) : 0.0;

    // Max drawdown
    double peak = 1.0, max_dd = 0.0, cumulative = 1.0;
    for (double r : returns) {
        cumulative *= (1.0 + r);
        peak = std::max(peak, cumulative);
        double dd = (peak - cumulative) / peak;
        max_dd = std::max(max_dd, dd);
    }
    rm.max_drawdown = max_dd;

    // Sharpe and Sortino
    double sum = std::accumulate(returns.begin(), returns.end(), 0.0);
    double mean = sum / n;
    double var_sum = 0.0, down_sum = 0.0;
    int n_down = 0;
    for (double r : returns) {
        var_sum += (r - mean) * (r - mean);
        if (r < 0) { down_sum += r * r; n_down++; }
    }
    double vol = std::sqrt(var_sum / n * annualization);
    double down_vol = n_down > 0 ? std::sqrt(down_sum / n_down * annualization) : 0.0;
    double ann_ret = mean * annualization;

    rm.sharpe = vol > 0 ? ann_ret / vol : 0.0;
    rm.sortino = down_vol > 0 ? ann_ret / down_vol : 0.0;

    return rm;
}

}  // namespace cpr
