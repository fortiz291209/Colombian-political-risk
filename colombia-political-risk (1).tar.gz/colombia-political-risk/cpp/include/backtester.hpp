/**
 * @file backtester.hpp
 * @brief High-performance event-driven backtesting engine for Colombian political risk strategies
 * @author Fernando Ortiz Sierra
 * @date 2021-2024
 * 
 * Performance-critical backtesting logic implemented in C++ for speed.
 * Python research code (src/) handles NLP, data ingestion, and visualization.
 * This C++ engine handles the inner loop: signal processing, position sizing,
 * portfolio simulation, and risk metrics computation over ~900 trading days.
 */

#pragma once

#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <stdexcept>
#include <unordered_map>

namespace cpr {  // colombian political risk

// ============================================================
// Data structures
// ============================================================

struct MarketBar {
    double open;
    double high;
    double low;
    double close;
    double volume;
    int date_idx;  // trading day index
};

struct Signal {
    int date_idx;
    int direction;       // +1 long, -1 short, 0 flat
    double strength;     // [0, 1]
    double sentiment_z;
    double market_z;
};

struct Trade {
    int entry_idx;
    int exit_idx;
    int direction;
    double entry_price;
    double exit_price;
    double size;
    double pnl;
    double cost;
    int holding_days;
};

struct PortfolioState {
    double capital;
    double position;
    double entry_price;
    int entry_idx;
    double portfolio_value;
    double peak_value;
    double drawdown;
};

struct PerformanceMetrics {
    double total_return;
    double annualized_return;
    double annualized_vol;
    double sharpe_ratio;
    double sortino_ratio;
    double calmar_ratio;
    double max_drawdown;
    double win_rate;
    double profit_factor;
    int total_trades;
    int winners;
    int losers;
    double avg_holding_days;
    double total_costs;
};

// ============================================================
// Configuration
// ============================================================

struct BacktestConfig {
    double initial_capital = 1'000'000.0;
    double max_position_pct = 0.10;
    double transaction_cost_bps = 15.0;
    double slippage_bps = 10.0;
    double max_drawdown_limit = 0.05;
    double drawdown_reduction = 0.50;
    double vol_target = 0.10;
    int vol_lookback = 20;
    int max_holding_days = 20;
    double min_signal_strength = 0.3;
};

// ============================================================
// Rolling Statistics (performance-critical)
// ============================================================

class RollingStats {
    /**
     * Online computation of rolling mean, variance, and z-score
     * using Welford's algorithm. O(1) per update.
     */
public:
    RollingStats(int window) : window_(window), count_(0), sum_(0), sum_sq_(0) {
        buffer_.reserve(window);
    }

    void update(double value) {
        if (static_cast<int>(buffer_.size()) >= window_) {
            double old = buffer_[count_ % window_];
            sum_ -= old;
            sum_sq_ -= old * old;
            buffer_[count_ % window_] = value;
        } else {
            buffer_.push_back(value);
        }
        sum_ += value;
        sum_sq_ += value * value;
        count_++;
    }

    double mean() const {
        int n = std::min(count_, window_);
        return n > 0 ? sum_ / n : 0.0;
    }

    double variance() const {
        int n = std::min(count_, window_);
        if (n < 2) return 0.0;
        double m = mean();
        return (sum_sq_ / n) - m * m;
    }

    double std_dev() const {
        return std::sqrt(std::max(0.0, variance()));
    }

    double z_score(double value) const {
        double s = std_dev();
        return s > 1e-10 ? (value - mean()) / s : 0.0;
    }

    bool is_ready() const { return count_ >= window_; }

private:
    int window_;
    int count_;
    double sum_;
    double sum_sq_;
    std::vector<double> buffer_;
};

// ============================================================
// Backtesting Engine
// ============================================================

class Backtester {
public:
    explicit Backtester(const BacktestConfig& config = BacktestConfig())
        : config_(config) {}

    /**
     * Run backtest over price series with pre-computed signals.
     * Returns vector of daily portfolio states.
     */
    std::vector<PortfolioState> run(
        const std::vector<MarketBar>& prices,
        const std::vector<Signal>& signals
    ) {
        trades_.clear();
        std::vector<PortfolioState> history;
        history.reserve(prices.size());

        PortfolioState state;
        state.capital = config_.initial_capital;
        state.position = 0.0;
        state.entry_price = 0.0;
        state.entry_idx = -1;
        state.peak_value = config_.initial_capital;
        state.portfolio_value = config_.initial_capital;
        state.drawdown = 0.0;

        // Build signal lookup
        std::unordered_map<int, Signal> signal_map;
        for (const auto& sig : signals) {
            signal_map[sig.date_idx] = sig;
        }

        // Compute rolling volatility
        RollingStats vol_stats(config_.vol_lookback);
        std::vector<double> returns(prices.size(), 0.0);
        for (size_t i = 1; i < prices.size(); ++i) {
            if (prices[i-1].close > 0) {
                returns[i] = std::log(prices[i].close / prices[i-1].close);
            }
        }

        for (size_t i = 0; i < prices.size(); ++i) {
            double price = prices[i].close;
            int date_idx = prices[i].date_idx;

            vol_stats.update(returns[i]);
            double current_vol = vol_stats.std_dev() * std::sqrt(252.0);

            // Get signal for this day
            Signal sig = {date_idx, 0, 0.0, 0.0, 0.0};
            auto it = signal_map.find(date_idx);
            if (it != signal_map.end()) {
                sig = it->second;
            }

            if (price <= 0 || std::isnan(price)) {
                history.push_back(state);
                continue;
            }

            // Mark to market existing position
            if (state.position != 0.0) {
                double mtm_pnl = state.position * (price - state.entry_price);
                int holding = date_idx - state.entry_idx;

                bool should_exit = false;
                if (holding >= config_.max_holding_days) should_exit = true;
                if (sig.direction != 0 && sig.direction != sign(state.position)) should_exit = true;

                // Drawdown control
                double current_value = state.capital + mtm_pnl;
                double dd = (state.peak_value - current_value) / state.peak_value;
                if (dd > config_.max_drawdown_limit) should_exit = true;

                if (should_exit) {
                    double notional = std::abs(state.position * price);
                    double cost = transaction_cost(notional);
                    double realized_pnl = mtm_pnl - cost;
                    state.capital += realized_pnl;

                    Trade trade;
                    trade.entry_idx = state.entry_idx;
                    trade.exit_idx = date_idx;
                    trade.direction = sign(state.position);
                    trade.entry_price = state.entry_price;
                    trade.exit_price = price;
                    trade.size = std::abs(state.position);
                    trade.pnl = realized_pnl;
                    trade.cost = cost;
                    trade.holding_days = holding;
                    trades_.push_back(trade);

                    state.position = 0.0;
                    state.entry_price = 0.0;
                    state.entry_idx = -1;
                }
            }

            // Entry logic
            if (state.position == 0.0 && sig.direction != 0 &&
                sig.strength >= config_.min_signal_strength && vol_stats.is_ready()) {
                
                double size = position_size(state.capital, price, current_vol, sig.strength);
                if (size > 0) {
                    double cost = transaction_cost(size * price);
                    state.position = size * sig.direction;
                    state.entry_price = price;
                    state.entry_idx = date_idx;
                    state.capital -= cost;
                }
            }

            // Update portfolio state
            state.portfolio_value = state.capital +
                (state.position != 0.0 ? state.position * (price - state.entry_price) : 0.0);
            state.peak_value = std::max(state.peak_value, state.portfolio_value);
            state.drawdown = (state.peak_value - state.portfolio_value) / state.peak_value;

            history.push_back(state);
        }

        return history;
    }

    /**
     * Compute performance metrics from backtest history.
     */
    PerformanceMetrics compute_metrics(const std::vector<PortfolioState>& history) const {
        PerformanceMetrics m{};

        if (history.size() < 2) return m;

        double start_val = history.front().portfolio_value;
        double end_val = history.back().portfolio_value;
        m.total_return = (end_val / start_val) - 1.0;

        int days = static_cast<int>(history.size());
        m.annualized_return = std::pow(1.0 + m.total_return, 252.0 / days) - 1.0;

        // Compute daily returns and volatility
        std::vector<double> daily_ret;
        daily_ret.reserve(history.size());
        for (size_t i = 1; i < history.size(); ++i) {
            if (history[i-1].portfolio_value > 0) {
                daily_ret.push_back(
                    history[i].portfolio_value / history[i-1].portfolio_value - 1.0);
            }
        }

        double sum_ret = std::accumulate(daily_ret.begin(), daily_ret.end(), 0.0);
        double mean_ret = sum_ret / daily_ret.size();
        double sum_sq = 0.0;
        double sum_sq_down = 0.0;
        int n_down = 0;
        for (double r : daily_ret) {
            sum_sq += (r - mean_ret) * (r - mean_ret);
            if (r < 0) {
                sum_sq_down += r * r;
                n_down++;
            }
        }

        m.annualized_vol = std::sqrt(sum_sq / daily_ret.size()) * std::sqrt(252.0);
        m.sharpe_ratio = m.annualized_vol > 0 ? m.annualized_return / m.annualized_vol : 0.0;

        double downside_vol = n_down > 0 ?
            std::sqrt(sum_sq_down / n_down) * std::sqrt(252.0) : 0.0;
        m.sortino_ratio = downside_vol > 0 ? m.annualized_return / downside_vol : 0.0;

        m.max_drawdown = 0.0;
        for (const auto& s : history) {
            m.max_drawdown = std::max(m.max_drawdown, s.drawdown);
        }
        m.calmar_ratio = m.max_drawdown > 0 ? m.annualized_return / m.max_drawdown : 0.0;

        // Trade statistics
        m.total_trades = static_cast<int>(trades_.size());
        m.winners = 0;
        m.losers = 0;
        double sum_win = 0.0, sum_loss = 0.0;
        double sum_hold = 0.0;
        m.total_costs = 0.0;

        for (const auto& t : trades_) {
            if (t.pnl > 0) { m.winners++; sum_win += t.pnl; }
            else { m.losers++; sum_loss += std::abs(t.pnl); }
            sum_hold += t.holding_days;
            m.total_costs += t.cost;
        }

        m.win_rate = m.total_trades > 0 ?
            static_cast<double>(m.winners) / m.total_trades : 0.0;
        m.profit_factor = sum_loss > 0 ? sum_win / sum_loss : 0.0;
        m.avg_holding_days = m.total_trades > 0 ? sum_hold / m.total_trades : 0.0;

        return m;
    }

    const std::vector<Trade>& get_trades() const { return trades_; }

private:
    BacktestConfig config_;
    std::vector<Trade> trades_;

    double transaction_cost(double notional) const {
        return notional * (config_.transaction_cost_bps + config_.slippage_bps) / 10'000.0;
    }

    double position_size(double capital, double price, double vol, double strength) const {
        if (vol <= 0 || price <= 0) return 0.0;
        double target_risk = capital * config_.vol_target * strength;
        double shares = target_risk / (price * vol);
        double max_shares = capital * config_.max_position_pct / price;
        return std::min(shares, max_shares);
    }

    static int sign(double x) {
        return (x > 0) - (x < 0);
    }
};

}  // namespace cpr
