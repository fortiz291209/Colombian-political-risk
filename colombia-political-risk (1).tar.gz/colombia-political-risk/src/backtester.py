"""
Event-Driven Backtesting Engine
Simulates strategy performance with realistic transaction costs,
slippage, position sizing, and drawdown controls.

Author: Fernando Ortiz Sierra
Period: 2021-2024
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional
from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)


@dataclass
class Trade:
    entry_date: pd.Timestamp
    exit_date: Optional[pd.Timestamp]
    asset: str
    direction: int
    entry_price: float
    exit_price: float = 0.0
    size: float = 0.0
    pnl: float = 0.0
    cost: float = 0.0
    trigger: str = ''
    holding_days: int = 0


@dataclass
class BacktestConfig:
    initial_capital: float = 1_000_000
    max_position_pct: float = 0.10
    transaction_cost_bps: float = 15.0
    slippage_bps: float = 10.0
    max_drawdown_limit: float = 0.05
    drawdown_reduction: float = 0.50
    vol_target: float = 0.10
    vol_lookback: int = 20
    max_holding_days: int = 20
    min_signal_strength: float = 0.3


class Backtester:
    """
    Event-driven backtester for Colombian political risk strategies.
    Processes signals sequentially, tracks portfolio state, and computes
    full performance analytics.
    """

    def __init__(self, config: Optional[BacktestConfig] = None):
        self.config = config or BacktestConfig()
        self.trades: List[Trade] = []
        self.portfolio_values = []
        self.positions = {}

    def _transaction_cost(self, notional: float) -> float:
        return notional * (self.config.transaction_cost_bps + self.config.slippage_bps) / 10_000

    def _position_size(self, capital: float, price: float, vol: float,
                       signal_strength: float) -> float:
        """Inverse-volatility position sizing with signal strength scaling."""
        if vol <= 0 or price <= 0:
            return 0
        target_risk = capital * self.config.vol_target * signal_strength
        shares = target_risk / (price * vol * np.sqrt(252))
        max_shares = capital * self.config.max_position_pct / price
        return min(shares, max_shares)

    def run(self, signals: pd.DataFrame, prices: pd.DataFrame,
            asset: str = 'usdcop') -> pd.DataFrame:
        """
        Run backtest.

        Parameters
        ----------
        signals : DataFrame with columns direction, strength, trigger
        prices : DataFrame with OHLCV columns for the target asset
        asset : asset name for price column lookup

        Returns
        -------
        DataFrame with daily portfolio values and analytics
        """
        price_col = f"{asset}_close"
        if price_col not in prices.columns:
            available = [c for c in prices.columns if 'close' in c.lower()]
            if available:
                price_col = available[0]
            else:
                raise ValueError(f"No price column found for {asset}")

        capital = self.config.initial_capital
        position = 0
        entry_price = 0
        entry_date = None
        peak_capital = capital
        trades = []
        daily = []

        # Compute rolling volatility
        returns = np.log(prices[price_col] / prices[price_col].shift(1))
        vol = returns.rolling(self.config.vol_lookback).std()

        aligned_signals = signals.reindex(prices.index).fillna(0)

        for date in prices.index:
            price = prices.loc[date, price_col]
            current_vol = vol.get(date, 0.15)
            sig_direction = aligned_signals.loc[date, 'direction'] if date in aligned_signals.index else 0
            sig_strength = aligned_signals.loc[date, 'strength'] if date in aligned_signals.index else 0
            sig_trigger = aligned_signals.loc[date, 'trigger'] if date in aligned_signals.index else ''

            if np.isnan(price) or price <= 0:
                daily.append({'date': date, 'capital': capital, 'position': position,
                            'price': price, 'pnl': 0})
                continue

            # Mark to market
            if position != 0:
                mtm_pnl = position * (price - entry_price)
                holding_days = (date - entry_date).days if entry_date else 0

                # Exit conditions
                exit_signal = False
                exit_reason = ''

                if holding_days >= self.config.max_holding_days:
                    exit_signal = True
                    exit_reason = 'max_holding'
                elif sig_direction != 0 and sig_direction != np.sign(position):
                    exit_signal = True
                    exit_reason = 'signal_reversal'

                # Drawdown control
                current_dd = (peak_capital - (capital + mtm_pnl)) / peak_capital
                if current_dd > self.config.max_drawdown_limit:
                    exit_signal = True
                    exit_reason = 'drawdown_limit'

                if exit_signal:
                    cost = self._transaction_cost(abs(position * price))
                    realized_pnl = mtm_pnl - cost
                    capital += realized_pnl

                    trades.append(Trade(
                        entry_date=entry_date, exit_date=date, asset=asset,
                        direction=int(np.sign(position)), entry_price=entry_price,
                        exit_price=price, size=abs(position), pnl=realized_pnl,
                        cost=cost, trigger=exit_reason, holding_days=holding_days
                    ))

                    position = 0
                    entry_price = 0
                    entry_date = None

            # Entry conditions
            if position == 0 and sig_direction != 0 and sig_strength >= self.config.min_signal_strength:
                size = self._position_size(capital, price, current_vol, sig_strength)
                if size > 0:
                    cost = self._transaction_cost(size * price)
                    position = size * sig_direction
                    entry_price = price
                    entry_date = date
                    capital -= cost

            # Track portfolio
            portfolio_value = capital + (position * (price - entry_price) if position != 0 else 0)
            peak_capital = max(peak_capital, portfolio_value)

            daily.append({
                'date': date,
                'capital': capital,
                'position': position,
                'price': price,
                'portfolio_value': portfolio_value,
                'drawdown': (peak_capital - portfolio_value) / peak_capital,
            })

        self.trades = trades
        results = pd.DataFrame(daily).set_index('date')
        logger.info(f"Backtest complete: {len(trades)} trades, final value: ${results['portfolio_value'].iloc[-1]:,.0f}")
        return results

    def trade_summary(self) -> Dict:
        """Compute trade-level statistics."""
        if not self.trades:
            return {}

        pnls = [t.pnl for t in self.trades]
        winners = [p for p in pnls if p > 0]
        losers = [p for p in pnls if p <= 0]

        return {
            'total_trades': len(self.trades),
            'winners': len(winners),
            'losers': len(losers),
            'win_rate': len(winners) / len(self.trades) if self.trades else 0,
            'avg_pnl': np.mean(pnls),
            'avg_winner': np.mean(winners) if winners else 0,
            'avg_loser': np.mean(losers) if losers else 0,
            'best_trade': max(pnls),
            'worst_trade': min(pnls),
            'total_pnl': sum(pnls),
            'profit_factor': abs(sum(winners) / sum(losers)) if losers and sum(losers) != 0 else np.inf,
            'avg_holding_days': np.mean([t.holding_days for t in self.trades]),
            'total_costs': sum(t.cost for t in self.trades),
        }

    def performance_metrics(self, results: pd.DataFrame) -> Dict:
        """Compute portfolio-level performance metrics."""
        pv = results['portfolio_value']
        returns = pv.pct_change().dropna()

        total_return = (pv.iloc[-1] / pv.iloc[0]) - 1
        days = (pv.index[-1] - pv.index[0]).days
        ann_return = (1 + total_return) ** (365 / days) - 1 if days > 0 else 0
        ann_vol = returns.std() * np.sqrt(252)
        sharpe = ann_return / ann_vol if ann_vol > 0 else 0
        max_dd = results['drawdown'].max()

        # Sortino
        downside = returns[returns < 0].std() * np.sqrt(252)
        sortino = ann_return / downside if downside > 0 else 0

        # Calmar
        calmar = ann_return / max_dd if max_dd > 0 else 0

        return {
            'total_return': total_return,
            'annualized_return': ann_return,
            'annualized_volatility': ann_vol,
            'sharpe_ratio': sharpe,
            'sortino_ratio': sortino,
            'calmar_ratio': calmar,
            'max_drawdown': max_dd,
            'final_value': pv.iloc[-1],
        }
