/**
 * @file pybindings.cpp
 * @brief CPython/NumPy bindings exposing C++ backtester and time series analytics to Python
 * @author Fernando Ortiz Sierra
 * @date 2021-2024
 *
 * Exposes the performance-critical C++ components to the Python research pipeline.
 * Usage from Python:
 *   import cpr_engine
 *   results = cpr_engine.run_backtest(prices, signals, config)
 *   zscores = cpr_engine.rolling_zscore(data, window)
 */

#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <numpy/arrayobject.h>

#include "backtester.hpp"
#include "timeseries.hpp"

#include <vector>
#include <stdexcept>

// ============================================================
// Helper: NumPy array -> std::vector<double>
// ============================================================

static std::vector<double> numpy_to_vector(PyArrayObject* arr) {
    npy_intp n = PyArray_SIZE(arr);
    double* data = static_cast<double*>(PyArray_DATA(arr));
    return std::vector<double>(data, data + n);
}

static PyObject* vector_to_numpy(const std::vector<double>& vec) {
    npy_intp n = static_cast<npy_intp>(vec.size());
    PyObject* arr = PyArray_SimpleNew(1, &n, NPY_DOUBLE);
    if (!arr) return nullptr;
    double* data = static_cast<double*>(PyArray_DATA(reinterpret_cast<PyArrayObject*>(arr)));
    std::copy(vec.begin(), vec.end(), data);
    return arr;
}

// ============================================================
// rolling_zscore(data, window)
// ============================================================

static PyObject* py_rolling_zscore(PyObject* self, PyObject* args) {
    PyArrayObject* arr;
    int window;

    if (!PyArg_ParseTuple(args, "O!i", &PyArray_Type, &arr, &window))
        return nullptr;

    auto data = numpy_to_vector(arr);
    auto result = cpr::rolling_zscore(data, window);
    return vector_to_numpy(result);
}

// ============================================================
// ewma(data, halflife)
// ============================================================

static PyObject* py_ewma(PyObject* self, PyObject* args) {
    PyArrayObject* arr;
    double halflife;

    if (!PyArg_ParseTuple(args, "O!d", &PyArray_Type, &arr, &halflife))
        return nullptr;

    auto data = numpy_to_vector(arr);
    auto result = cpr::ewma(data, halflife);
    return vector_to_numpy(result);
}

// ============================================================
// rolling_volatility(returns, window)
// ============================================================

static PyObject* py_rolling_volatility(PyObject* self, PyObject* args) {
    PyArrayObject* arr;
    int window;

    if (!PyArg_ParseTuple(args, "O!i", &PyArray_Type, &arr, &window))
        return nullptr;

    auto data = numpy_to_vector(arr);
    auto result = cpr::rolling_volatility(data, window);
    return vector_to_numpy(result);
}

// ============================================================
// event_study_car(treatment, market, est_start, est_end, event_idx, post_window)
// ============================================================

static PyObject* py_event_study(PyObject* self, PyObject* args) {
    PyArrayObject* treat_arr;
    PyArrayObject* market_arr;
    int est_start, est_end, event_idx, post_window;

    if (!PyArg_ParseTuple(args, "O!O!iiii",
                          &PyArray_Type, &treat_arr,
                          &PyArray_Type, &market_arr,
                          &est_start, &est_end, &event_idx, &post_window))
        return nullptr;

    auto treatment = numpy_to_vector(treat_arr);
    auto market = numpy_to_vector(market_arr);

    auto ols = cpr::ols_market_model(treatment, market, est_start, est_end);
    auto car = cpr::cumulative_abnormal_returns(
        treatment, market, ols.alpha, ols.beta, event_idx, post_window);

    // Return dict with alpha, beta, r2, residual_std, car array
    PyObject* car_arr = vector_to_numpy(car);
    PyObject* result = Py_BuildValue("{s:d, s:d, s:d, s:d, s:O}",
        "alpha", ols.alpha,
        "beta", ols.beta,
        "r_squared", ols.r_squared,
        "residual_std", ols.residual_std,
        "car", car_arr
    );
    Py_DECREF(car_arr);
    return result;
}

// ============================================================
// risk_metrics(returns)
// ============================================================

static PyObject* py_risk_metrics(PyObject* self, PyObject* args) {
    PyArrayObject* arr;
    if (!PyArg_ParseTuple(args, "O!", &PyArray_Type, &arr))
        return nullptr;

    auto returns = numpy_to_vector(arr);
    auto rm = cpr::compute_risk_metrics(returns);

    return Py_BuildValue("{s:d, s:d, s:d, s:d, s:d, s:d, s:d}",
        "var_95", rm.var_95,
        "var_99", rm.var_99,
        "cvar_95", rm.cvar_95,
        "cvar_99", rm.cvar_99,
        "max_drawdown", rm.max_drawdown,
        "sharpe", rm.sharpe,
        "sortino", rm.sortino
    );
}

// ============================================================
// Module definition
// ============================================================

static PyMethodDef CprMethods[] = {
    {"rolling_zscore", py_rolling_zscore, METH_VARARGS,
     "Compute rolling z-score. Args: data (ndarray), window (int)"},
    {"ewma", py_ewma, METH_VARARGS,
     "Exponentially weighted moving average. Args: data (ndarray), halflife (float)"},
    {"rolling_volatility", py_rolling_volatility, METH_VARARGS,
     "Rolling annualized volatility. Args: returns (ndarray), window (int)"},
    {"event_study", py_event_study, METH_VARARGS,
     "Run event study. Args: treatment, market, est_start, est_end, event_idx, post_window"},
    {"risk_metrics", py_risk_metrics, METH_VARARGS,
     "Compute risk metrics (VaR, CVaR, Sharpe, Sortino). Args: returns (ndarray)"},
    {nullptr, nullptr, 0, nullptr}
};

static struct PyModuleDef cprmodule = {
    PyModuleDef_HEAD_INIT,
    "cpr_engine",
    "Colombian Political Risk - C++ accelerated analytics engine.\n"
    "Provides fast rolling statistics, event study computation,\n"
    "and risk metrics for the Python research pipeline.",
    -1,
    CprMethods
};

PyMODINIT_FUNC PyInit_cpr_engine(void) {
    import_array();
    return PyModule_Create(&cprmodule);
}
