# Research Methodology

## Overview

This document describes the full research methodology developed over June 2021 to July 2024
for the Colombian Political Risk and Commodity/FX Market Dynamics project.

## 1. Research Question

Can NLP-derived political sentiment from Colombian government communications predict
short-horizon returns in oil and FX markets, and can contrarian positioning on these signals
generate risk-adjusted alpha after transaction costs?

## 2. Data

### Market Data
- Daily OHLCV: Brent, WTI, gold, USD/COP, USD/BRL, USD/MXN, COLCAP, Ecopetrol
- Macro controls: VIX, DXY, US 10Y, EM sovereign spreads, Colombian policy rate
- Period: January 2021 to July 2024 (~900 trading days)

### Political Data
- Presidential press releases and speeches (Presidencia de la Republica)
- Ministerial communications (MinMinas, MinHacienda)
- Congressional voting records and committee transcripts
- Official social media accounts
- Total corpus: ~2,400 documents across 3 years

## 3. NLP Pipeline

### Sentiment Extraction
- Model: GPT-4 via OpenAI API
- Language: Spanish (native, no translation layer)
- Scoring: 5 dimensions x [-1, +1] scale per document
- Calibration: Dimension weights optimized against next-week USD/COP realized volatility
- Validation: Manual scoring of 200 randomly sampled documents, correlation with LLM scores: 0.78

### Aggregation
- Daily composite: weighted average of 5 dimensions
- Smoothing: 5-day exponential moving average
- Normalization: 60-day rolling z-score

## 4. Signal Construction

### Contrarian Logic
The core insight: markets overreact to Colombian political headlines. When the NLP pipeline
detects very negative sentiment AND market indicators (CDS, FX implied vol) are already
elevated beyond 2 standard deviations, the political risk is already priced in. Contrarian
long positioning captures the mean-reversion.

### Regime Filter
Signals are suppressed when VIX > 30 to avoid trading against global systemic risk events
that dominate country-specific dynamics.

## 5. Econometric Validation

### Event Study
- Market model estimated on [-120, -20] pre-event window
- Abnormal returns computed over [0, +5], [0, +10], [0, +20] windows
- t-statistics computed using estimation-window residual standard deviation

### Difference-in-Differences
- Treatment: Colombian assets (USD/COP, Ecopetrol, COLCAP)
- Control: EM peers (EEM, USD/BRL, USD/MXN)
- Parallel trends tested on [-60, -1] pre-event window via trend regression

## 6. Backtesting

### Engine Design
- Event-driven (not vectorized) to reflect realistic execution
- Transaction costs: 15bps spread + 10bps slippage (calibrated to Colombian FX market)
- Position sizing: inverse-volatility with signal strength scaling
- Risk controls: 5% max drawdown trigger, 20-day max holding period
- Multiple parameter configurations tested for robustness

## 7. Key Findings

1. NLP sentiment has statistically significant predictive power for next-week USD/COP
   returns (t-stat > 2.0) when combined with market-implied risk indicators
2. The 2022 Petro election generated the largest abnormal returns in the sample, with
   CAR[0,+20] of +5.1% for USD/COP (t-stat = 2.87)
3. Contrarian signals correctly anticipated post-election mean-reversion in 7 of 10 events
4. Strategy Sharpe ratio is sensitive to transaction cost assumptions

## 8. Limitations

- Small sample of political events (10 major events over 3 years)
- NLP scores depend on LLM model version and prompt calibration
- Transaction cost assumptions based on institutional-level access
- No out-of-sample testing (entire period used for development)
- Colombian FX market liquidity constraints at larger position sizes
