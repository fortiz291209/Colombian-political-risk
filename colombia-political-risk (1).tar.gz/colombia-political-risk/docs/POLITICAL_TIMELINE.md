# Colombian Political Events Timeline: 2021-2024

## Pre-Election Period (2021 - May 2022)

| Date | Event | Relevance |
|------|-------|-----------|
| Apr 2021 | National protests begin | Social unrest, CDS widening |
| Jun 2021 | Tax reform withdrawn | Fiscal uncertainty |
| Nov 2021 | Petro leads polls | First sustained polling lead |
| Mar 2022 | Congressional elections | Left gains seats |
| May 2022 | Petro wins first round (40.3%) | USD/COP +3.2% same week |

## Election and Transition (Jun - Aug 2022)

| Date | Event | Relevance |
|------|-------|-----------|
| Jun 19, 2022 | Petro wins presidency (50.4% vs Hernandez) | USD/COP +5.1%, COLCAP -4.3% |
| Jul 2022 | Cabinet announced | Mining/energy minister appointments |
| Aug 2022 | Drilling moratorium rhetoric | Ecopetrol -8.2%, oil sector stress |

## First Year (Sep 2022 - Aug 2023)

| Date | Event | Relevance |
|------|-------|-----------|
| Nov 2022 | Tax reform passed | Mixed: revenue positive, investment negative |
| Mar 2023 | Ecopetrol dividend policy shift | Ecopetrol -6.4% |
| Jun 2023 | Mining regulation proposal | Colombian CDS +45bps |
| Aug 2023 | First cabinet reshuffle | Political stability concerns |

## Second Year (Sep 2023 - Jul 2024)

| Date | Event | Relevance |
|------|-------|-----------|
| Dec 2023 | Political crisis deepens | USD/COP +2.8% |
| Feb 2024 | Health reform collapse | COLCAP +3.1% (relief rally) |
| Mar 2024 | Pension reform debate | Fiscal uncertainty |
| May 2024 | Energy transition rhetoric softens | Moderate relief in oil sector |
